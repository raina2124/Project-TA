import sqlite3

def setup_database():
    # Connect to the database (or create it if it doesn't exist)
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create a table for user credentials
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')

    # Insert a test user
    cursor.execute('''
        INSERT OR IGNORE INTO users (username, password)
        VALUES ('testuser', 'testpassword')
    ''')

    # Create a table for products
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT
        )
    ''')

    # Insert some sample products
    cursor.executemany('''
        INSERT OR IGNORE INTO products (name, description)
        VALUES (?, ?)
    ''', [
        ('Product1', 'Description1'),
        ('Product2', 'Description2'),
        ('Product3', 'Description3')
    ])

    # Commit changes and close the connection
    conn.commit()
    conn.close()

if __name__ == '__main__':
    setup_database()
